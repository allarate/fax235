import { resolve } from 'path';

import nesting from 'postcss-nesting';
import mixins from 'postcss-mixins';
import prefix from 'postcss-prefixer';

export default function createConfig(basedir, moduleName) {
  const rollupOptions = moduleName === 'picmo' ? {} : {
    external: ['picmo'],
    output: {
      globals: {
        picmo: 'picmo'
      }
    }
  };

  return {
    define: {
      'process.env.NODE_ENV': JSON.stringify('production')
    },
    css: {
      postcss: {
        plugins: [
          prefix({ prefix: 'picmo__' }),
          mixins(),
          nesting(),
        ]
      }
    },
    build: {
      rollupOptions,
      sourcemap: true,
      lib: {
        entry: resolve(basedir, 'src/index.ts'),
        name: moduleName,
        formats: ['es', 'umd'],
        fileName: format => {
          if (format === 'es') {
            return 'index.js';
          }
  
          if (format === 'umd') {
            return `umd/index.js`;
          }
        }
      }
    }
  };
}